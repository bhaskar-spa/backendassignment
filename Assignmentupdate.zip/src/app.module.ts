import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserModule } from './modules/users/user.module';
import { ProductModule } from './modules/products/product.module';
import { OrderModule } from './modules/orders/order.module';
import { GraphQLModule } from '@nestjs/graphql';
import { Product } from './modules/products/product.model';
import { Order } from './modules/orders/order.model';
import { User } from './modules/users/user.model';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'example',
      password: 'example',
      database: 'example',
      entities: [ Team, User ],
      synchronize: true,
    }),
    GraphQLModule.forRoot({ autoSchemaFile: true }),

    UserModule,
    ProductModule,
  ],
})
export class AppModule {
}
