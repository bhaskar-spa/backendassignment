import { Body, Controller, Get, NotFoundException, Param, Post } from '@nestjs/common';
import { OrderInput } from './order.model';
import { OrderService } from './order.service';

@Controller('orders')
export class OrderController {

  constructor(
    private readonly orderService: PrderService,
  ) {
  }

  @Get(':ordId')
  async getOrderById(@Param('ordID') ordID: number) {
    const order = await this.orderService.findById(ordID);

    if (!order) {
      throw new NotFoundException('Order not found');
    }

    return { order };
  }

  @Post()
  async createOrder(@Body() data: OrderInput) {
    const order = await this.orderService.createOrder(data);
    return { order };
  }
}
