import {
  Column,
  CreateDateColumn,
  Entity,
  JoinTable,
  ManyToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Field, InputType, Int, ObjectType } from '@nestjs/graphql';
import { User } from '../users/user.model';
import { Product } from '../products/product.model';

@Entity('orders')
@ObjectType()
export class Product {
  @PrimaryGeneratedColumn()
  @Field(() => Int)
  ordId: number;

  @Column()
  @Field({ nullable: false })
  dateOrdered: string;

  @Column()
  @Field({ nullable: false })
  customer: object;

  @Column()
  @Field({ nullable: false })
  product: object;

  @ManyToMany(() => User, user => user.products)
  @JoinTable()
  @Field(type => [ User ], { nullable: true })
  members: Promise<User[]>;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

@InputType()
export class ProductInput {
  @Field({ nullable: false })
  name: string;
}