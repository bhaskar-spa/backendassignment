import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrderService } from './Order.service';
import { OrderController } from './Order.controller';
import { Order } from './Order.model';
import { OrderResolver } from './Order.resolver';
import { UserModule } from '../users/user.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([ Product ]),
    forwardRef(() => UserModule),
  ],
  providers: [ OrderService, OrderResolver ],
  exports: [ OrderService ],
  controllers: [ OrderController ],
})
export class OrderModule {
}
