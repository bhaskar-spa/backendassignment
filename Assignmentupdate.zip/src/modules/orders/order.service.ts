import { forwardRef, Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';

import { Order, OrderInput } from './order.model';
import { UserService } from '../users/user.service';

@Injectable()
export class OrderService {

  constructor(
    @InjectRepository(Order)
    private readonly orderRepository: Repository<Order>,
    @Inject(forwardRef(() => UserService))
    private readonly userService: UserService,
  ) {
  }

  findById(ordId: number) {
    return this.orderRepository.findOne({ ordId }, {
      relations: [ 'members' ],
    });
  }

  createOrder(data: OrderInput) {
    const product = this.orderRepository.create(data);
    return this.orderRepository.save(order);
  }

  async addOrder(ordId: number, userId: number) {
    const order = await this.findById(ordId);

    if (!order) return null;

    const user = await this.userService.findById(userId);
    if (user) {
      (await order.members).push(user);

      await this.orderRepository.save(order);
    }

    return order;
  }

}
