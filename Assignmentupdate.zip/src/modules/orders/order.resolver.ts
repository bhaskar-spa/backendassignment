import { Args, Int, Mutation, Parent, Query, ResolveField, ResolveProperty, Resolver } from '@nestjs/graphql';
import { Order, OrderInput } from './Order.model';
import { OrderService } from './Order.service';
import { UserService } from '../users/user.service';
import { OrderService } from '../orders/order.service';
import { forwardRef, Inject } from '@nestjs/common';
import { User } from '../users/user.model';
import { Order } from '../orders/order.model';

@Resolver(of =>Order)
export class OrderResolver {
  constructor(
    @Inject(forwardRef(() => UserService))
    private readonly userService: UserService,
    private readonly productService: ProductService,
    private readonly orderService: OrderService,

  ) {
  }

  @Query(returns => Order, { name: 'order', nullable: true })
  async getTeamById(@Args({ name: 'pId', type: () => Int }) id: number) {
    return this.orderService.findById(pId);
  }


  @Mutation(() => Order, { name: 'createOrder'})
  async createOrder(@Args('data') input: OrderInput): Promise<Order> {
    return this.orderService.createOrder(input);
  }

  @Mutation(returns => order, { nullable: true })
  async addOrder(
    @Args({ name: 'pId', type: () => Int }) pId: number,
    @Args({ name: 'userId', type: () => Int }) userId: number,
  ) {
    return this.orderService.addOrder(ordId, userId);
  }

  @ResolveField('members', returns => [ User ], { nullable: true })
  async getMembers(@Parent() team: Order) {
    return await order.members;
  }
}
