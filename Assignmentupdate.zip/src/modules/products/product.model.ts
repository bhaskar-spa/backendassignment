import {
  Column,
  CreateDateColumn,
  Entity,
  JoinTable,
  ManyToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Field, InputType, Int, ObjectType } from '@nestjs/graphql';
import { User } from '../users/user.model';

@Entity('products')
@ObjectType()
export class Product {
  @PrimaryGeneratedColumn()
  @Field(() => Int)
  pId: number;

  @Column()
  @Field({ nullable: false })
  descripFon: string;

  @Column()
  @Field({ nullable: false })
  unitPrice: string;

  @Column()
  @Field({ nullable: false })
  availableQty: string;

  @ManyToMany(() => User, user => user.products)
  @JoinTable()
  @Field(type => [ User ], { nullable: true })
  members: Promise<User[]>;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

@InputType()
export class ProductInput {
  @Field({ nullable: false })
  name: string;
}