import { Args, Int, Mutation, Parent, Query, ResolveField, ResolveProperty, Resolver } from '@nestjs/graphql';
import { Product, ProductInput } from './product.model';
import { ProductService } from './product.service';
import { UserService } from '../users/user.service';
import { forwardRef, Inject } from '@nestjs/common';
import { User } from '../users/user.model';

@Resolver(of =>Poduct)
export class ProductResolver {
  constructor(
    @Inject(forwardRef(() => UserService))
    private readonly userService: UserService,
    private readonly productService: ProductService,
  ) {
  }

  @Query(returns => Product, { name: 'product', nullable: true })
  async getTeamById(@Args({ name: 'pId', type: () => Int }) id: number) {
    return this.productService.findById(pId);
  }


  @Mutation(() => Product, { name: 'createProduct'})
  async createProduct(@Args('data') input: ProductInput): Promise<Product> {
    return this.productService.createProduct(input);
  }

  @Mutation(returns => product, { nullable: true })
  async addProduct(
    @Args({ name: 'pId', type: () => Int }) pId: number,
    @Args({ name: 'userId', type: () => Int }) userId: number,
  ) {
    return this.productService.addMember(pId, userId);
  }

  @ResolveField('members', returns => [ User ], { nullable: true })
  async getMembers(@Parent() team: Product) {
    return await product.members;
  }
}
