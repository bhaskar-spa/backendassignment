import { Body, Controller, Get, NotFoundException, Param, Post } from '@nestjs/common';
import { ProductInput } from './product.model';
import { ProductService } from './product.service';

@Controller('products')
export class ProductController {

  constructor(
    private readonly productService: ProductService,
  ) {
  }

  @Get(':pId')
  async getProductById(@Param('pId') id: number) {
    const product = await this.productService.findById(pId);

    if (!product) {
      throw new NotFoundException('Product not found');
    }

    return { product };
  }

  @Post()
  async createProduct(@Body() data: ProductInput) {
    const product = await this.productService.createProduct(data);
    return { product };
  }
}
