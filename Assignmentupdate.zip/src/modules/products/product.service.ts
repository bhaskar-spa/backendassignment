import { forwardRef, Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';

import { Product, ProductInput } from './product.model';
import { UserService } from '../users/user.service';

@Injectable()
export class ProductService {

  constructor(
    @InjectRepository(Product)
    private readonly productRepository: Repository<Product>,
    @Inject(forwardRef(() => UserService))
    private readonly userService: UserService,
  ) {
  }

  findById(pId: number) {
    return this.productRepository.findOne({ pId }, {
      relations: [ 'members' ],
    });
  }

  createProduct(data: ProductInput) {
    const product = this.productRepository.create(data);
    return this.productRepository.save(product);
  }

  async addProduct(pId: number, userId: number) {
    const product = await this.findById(pId);

    if (!product) return null;

    const user = await this.userService.findById(userId);
    if (user) {
      (await product.members).push(user);

      await this.productRepository.save(product);
    }

    return product;
  }

}
