import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductService } from './product.service';
import { ProductController } from './product.controller';
import { Product } from './product.model';
import { ProductResolver } from './product.resolver';
import { UserModule } from '../users/user.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([ Product ]),
    forwardRef(() => UserModule),
  ],
  providers: [ ProductService, ProductResolver ],
  exports: [ ProductService ],
  controllers: [ ProductController ],
})
export class ProductModule {
}
