import { forwardRef, Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { ProductService } from '../product/product.service';

import { User, UserInput } from './user.model';

@Injectable()
export class UserService {

  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    @Inject(forwardRef(() => ProductService))
    private readonly teamService: ProductService,
  ) {}

  findById(id: number) {
    return this.userRepository.findOne({ id }, {
      relations: [ 'product' ],
    });
  }

  async createUser( data: UserInput ) {
    const user = await this.userRepository.save(
      this.userRepository.create(data)
    );
    if(data.pId) {
      await this.productService.addMember(data.pId, user.id);
    }
    return user;
  }

  findByIds(ids: number[]) {
    return this.userRepository.find({
      where: { custId: In(ids) },
      relations: [ 'product' ],
    });
  }

}
