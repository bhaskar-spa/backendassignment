import { Int, Args, Parent, Query, Mutation, Resolver, ResolveField } from '@nestjs/graphql';
import { User, UserInput } from './user.model';
import { UserService } from './user.service';
import { ProductService } from '../product/product.service';
import { forwardRef, Inject } from '@nestjs/common';
import { Product } from '../product/product.model';

@Resolver(of => User)
export class UserResolver {
  constructor(
    private readonly userService: UserService,
    @Inject(forwardRef(() => ProductService))
    private readonly productService: ProductService,
  ) { }

  @Query(returns => User, { name: 'user', nullable: true })
  async getUserById(@Args({ name: 'custId', type: () => Int }) custId: number) {
    return this.userService.findById(custId);
  }

  @Mutation(() => User, { name: 'createUser'})
  async createUser(@Args('data') input: UserInput): Promise<User> {
    return this.userService.createUser(input);
  }

  @ResolveField('product', () => [Product], {nullable: false})
  async getProduct(@Parent() user: User) {
    return await user.product;
  }
}
