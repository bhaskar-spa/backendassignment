import { Column, CreateDateColumn, Entity, ManyToMany, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { Field, Int, ObjectType, InputType } from '@nestjs/graphql';
import { Team } from '../teams/team.model';

@Entity('users')
@ObjectType()
export class User {
  @PrimaryGeneratedColumn()
  @Field(() => Int)
  custId: number;

  @Column()
  @Field({ nullable: false })
  firstName: string;

  @Column()
  @Field({ nullable: false })
  lastName: string;

  @Column()
  @Field({ nullable: false })
  gender: string;  

  @Column()
  @Field({ nullable: false })
  email: string;

  @Column()
  @Field({ nullable: false })
  landLine: string;

  @Column()
  @Field({ nullable: false })
  mobile: string;

  @Column()
  @Field({ nullable: false })
  address: object;

  // @ManyToMany(() => Product, product => product.members)
  // @Field(type => [ Team ], { nullable: true })
  // teams: Promise<Team[]>;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

@InputType()
export class UserInput {
  @Field({ nullable: false })
  firstName: string;

  @Field({ nullable: false })
  lastName: string;

  // @Field(() => Int, { nullable: true })
  // teamId?: number;
}